//Declaração de variáveis
//Comente e descomente para ver os erros
void main(){
   //Erro 1
    int x = 0;
    String x = 2;

    // //Erro2
    // int a = "a";

    // //Erro3
    // List<String> = ["a","",3];

    // //Erro4;
    // void c = 2;

    // //Erro5
    // List <void> c  = [1];

    // //Erro6
    // List<List <String> > b = [[""]];

    // //Erro7
    // List <int> e = [[1]];

}