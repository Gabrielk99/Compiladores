//DO while
//Comente e descomente pra ver o erro
void main(){

    do{    }while(1); //erro1

    //do{    }while(); //erro2

    //do {    } //erro3

    

}