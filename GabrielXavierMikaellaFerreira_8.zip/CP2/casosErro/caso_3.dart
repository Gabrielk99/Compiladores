//Operadores comparacionais
//Comentar para ver os efeitos separados
void main(){

    bool x = "s">true; //erro 1
    int v = 4 < 3; //erro 2

    bool y = true <= false; //erro 3
    bool z = false >= true; //erro 5


}