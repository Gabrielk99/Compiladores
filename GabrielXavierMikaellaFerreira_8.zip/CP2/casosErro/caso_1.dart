//Caso com if 
//Comentar para ver o efeito de cada erro
void main(){

    if("BOBO"); //erro 1
    if(true);
    //else(true); //erro 2
    //if{} //erro 3
    

}