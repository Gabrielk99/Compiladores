void main(){
  double x = x+1.15 * 60/2;
  int k = 10 - x;
}