void func1(){
  return;
}

void main(){
  void func2(){
      int func1(int x){
        return x;
      }
  }

  int k = func1(2);
}