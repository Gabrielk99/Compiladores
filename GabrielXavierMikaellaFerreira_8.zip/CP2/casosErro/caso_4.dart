//while 
//Comente e descomente para ver os efeitos
void main(){

    while(3+5){

    } //erro1

    // while(){} //erro2 
 
    //while(1){} //erro3

    //while("ss"){} //erro4



}