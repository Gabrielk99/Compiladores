void main(){
  List<int> k = [1,2,3,4,5];
  //k += 6;

  int x = 10;
  double y = 5.2, z;
  String b;

  //x -= x + 5.0;

  b = "Batata quente quente quente quente";
  b-= " quente";
}