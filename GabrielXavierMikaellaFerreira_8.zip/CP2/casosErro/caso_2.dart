//Operadores logicos
//Descomentar e comentar para ver os efeitos
bool a = false;
bool b = true;

void main(){
    bool x = a && b;
    //x = a | b; //erro 2
    x = a || 2; //erro 3
    //x = a &| b; //erro 4
    //int x = a && b;//erro 5 
}