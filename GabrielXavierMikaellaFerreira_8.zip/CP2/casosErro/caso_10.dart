double doSomething(int x, double k){
  int j = 10;
  return j*k + x;
}

String doSomething(){
  return "Estou fazendo algo";
}

void main(){
  doSomething();
}