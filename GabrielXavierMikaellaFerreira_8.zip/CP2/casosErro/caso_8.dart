String hum = "humm...dois3";

void main(){
  for(int i = 0; i; i++){
    print("sera?");
  }
}