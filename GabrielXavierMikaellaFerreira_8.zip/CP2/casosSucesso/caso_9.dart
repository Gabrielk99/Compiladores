double quad(double x){
  return x*x;
}

void main(){
  double x = 15;
  int y = 2, k = 13;
  x = 14* 5/2 - 2*10 *(x+y/4.1);

  double dec;
  dec = x % (5 + y);

  int resultado;
  resultado = (k -3.56) ~/ quad(y);
}