//while 

void main (){

    int i = 0;

    while(i < 5){
        i+=1;
        int x = i;
    }

    while(true){
        String x = readLine();
        print("BATATA"+x);
    }


}