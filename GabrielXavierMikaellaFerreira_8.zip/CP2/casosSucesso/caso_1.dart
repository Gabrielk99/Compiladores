//Caso com if

bool x = true;
void main(){

    if(x){

    }
    else if(false){ 
        if(false);
    }
    else {
        if(x);
    }


}