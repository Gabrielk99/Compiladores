//DO while

void main(){
    List <bool> x = [true];
    do {
        print("EITA NOIX PATRAO");
    } while(x[0]);
    
    int i = 0;
    
    do {
        print("JABA");
        i+=1;
    } while(i<5);
}