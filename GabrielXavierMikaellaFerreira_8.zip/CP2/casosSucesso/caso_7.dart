String b,g,s;

void main(){
  List<int> k = [1,2,3,4,5];
  k += [6, 7];

  int x = 10;
  double y = 5.2, z;

  y -= x + 5;
  z = 235.34 + x;
  z /= y+x;
  x *= 5;

  b = "Batata quente quente quente quente";

  b+= " quente";
}