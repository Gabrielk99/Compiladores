int main(){
  void algoLegal(int valor, String s){
    print(valor);

    void outraCoisaLegal(double valor){
      print(s);
      valor += 10;
    }

    outraCoisaLegal(5.3);
  }
  return 10;
}