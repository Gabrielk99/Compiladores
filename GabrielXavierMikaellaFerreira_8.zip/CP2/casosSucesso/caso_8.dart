double k =1, z, j = 5;

void main(){
    for(int i = 0; i<10; i++){
      int x  = 10;
      x += 15;
    }

    for(double k = 15.3; k<20.3;)
      k += 0.2;

    String s = "oi";
    for(; s == "oi";);

    int i = 0;
    for(i = 15;; i++){
      print(k);
      double x = k+j;
    }

    for(int i=0; ;){
      print(i);
      print(z);
      print(s);
    }
    for(; ; k++);
    for(;k<20;k++);
    for(;;);
}