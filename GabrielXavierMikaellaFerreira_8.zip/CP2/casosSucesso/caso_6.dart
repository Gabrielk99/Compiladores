//Declarações de variáveis

int x = 4;
double y = 5;
double c = 5.5;
String b = "BTA";

void main(){

    List<bool> a = [true,false];
    List<String> b = ["AS","as"];
    List<int> x = [1,2,3];
    List <double> y = [1.3,3.0,4.2];
    List <void> v = [];
    void c;

}