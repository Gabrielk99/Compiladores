double doSomething(int x, double k){
  int j = 10;
  return j*k + x;
}

void main(){
  String doSomething(){
    return "Estou fazendo algo";
  }

  doSomething();
}