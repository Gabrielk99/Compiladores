//Operadores Comparacionais
void main(){
    List <int> a = [1];
    bool x = 3 < 4;
    x = 5 > 2;
    x = "ab" == "ab";
    x = a!=2;
    x = 3<=3;
    x = 3>=4;
    //x = a[0] < 3;




}